<div class="sidebar"> 
	<ul>
		<li><h2>Categories</h2>  
		<ul> <?php wp_list_cats('sort_column=name&optioncount=1&hierarchical=0'); ?> </ul> 
		</li>
	</ul>
</div>