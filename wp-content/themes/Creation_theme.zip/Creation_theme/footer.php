<div id="footer">
	<div class="container">
		<div class="row">
			<div class="col-lg-2">
				<img id="logo_footer" src="wp-content/themes/Creation_theme/images/logo_footer.png">
			</div>
			<div class="col-lg-7">
				<ul id="menu_footer">
					<li><a href="#">Home</a></li>
					<li><a href="#">DIY</a></li>
					<li><a href="#">Beauté</a></li>
					<li><a href="#">Contact</a></li>
					<li><a href="#">Mentions légales</a></li>
				</ul>
				<p>Copyright &#169; <?php bloginfo('name'); ?>  -  <?php print(date(Y)); ?></p>
			</div>
			<div class="col-lg-3">
				<div class="rs_footer">
					<i class="fa fa-facebook fa-3x"></i>
					<i class="fa fa-twitter fa-3x"></i>
					<i class="fa fa-pinterest fa-3x"></i>
					<i class="fa fa-instagram fa-3x"></i>
				</div>
			</div>
		</div>
	</div>


<!--  <p> Copyright &#169; <?php print(date(Y)); ?> <?php bloginfo('name'); ?> <br />
  Blog propulsé par 
  <a href="http://wordpress.org/">WordPress</a> et con&ccedil;u par 
  <a href="http://www.fran6art.com">Fran6art</a> <br /> 
  <a href="feed:<?php bloginfo('rss2_url'); ?>">Articles (RSS)</a> et 
  <a href="feed:<?php bloginfo('comments_rss2_url'); ?>">Commentaires (RSS)</a>. 
  <?php echo get_num_queries(); ?> requêtes. <?php timer_stop(1); ?> secondes. </p> -->
</div>